from pydantic import BaseModel, EmailStr, Field
from typing import Optional

class RegisterIn(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length=6)
    role: str = "candidate"
    location: str = ""

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class SkillIn(BaseModel):
    name: str
    level: int = Field(ge=1, le=5)

class JobOut(BaseModel):
    id: int
    title: str
    company: str
    location: str
    remote: bool
    salary_min: int
    salary_max: int
    description: str
    skills: list[str]
    inclusive: bool

class MatchOut(JobOut):
    score: int
    reasons: list[str]

class ApplicationIn(BaseModel):
    job_id: int

class CareerOut(BaseModel):
    target_role: str
    readiness: int
    gap_skills: list[str]
    strengths: list[str]
    next_actions: list[str]
