from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..auth import current_user
from ..models import User, Job, Application
from ..services.matching import score_job

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("")
def dashboard(user: User = Depends(current_user), db: Session = Depends(get_db)):
    jobs = db.query(Job).all()
    scores = [score_job(user, j)[0] for j in jobs]
    applications = db.query(Application).filter(Application.user_id == user.id).count()
    avg = round(sum(scores)/len(scores)) if scores else 0
    return {
        "profile_completion": min(100, 30 + len(user.skills) * 12),
        "match_score": avg,
        "applications": applications,
        "skill_count": len(user.skills),
        "recommended_jobs": len([s for s in scores if s >= 70]),
        "impact": {"sdg8": 82, "sdg4": 76, "sdg5": 71, "sdg9": 79, "sdg10": 74}
    }
