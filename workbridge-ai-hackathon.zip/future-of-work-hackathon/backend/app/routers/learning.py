from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..auth import current_user
from ..models import User, LearningResource
from ..services.career import build_career_plan
from ..models import Job

router = APIRouter(prefix="/learning", tags=["Learning"])

@router.get("/plan")
def plan(user: User = Depends(current_user), db: Session = Depends(get_db)):
    career = build_career_plan(user, db.query(Job).all())
    resources = db.query(LearningResource).all()
    gaps = {g.lower() for g in career["gap_skills"]}
    selected = [r for r in resources if r.skill.lower() in gaps]
    return {"career": career, "resources": [{"title": r.title, "provider": r.provider, "skill": r.skill, "hours": r.hours, "level": r.level, "url": r.url, "free": r.free} for r in selected]}

@router.get("/resources")
def resources(db: Session = Depends(get_db)):
    return [{"id": r.id, "title": r.title, "provider": r.provider, "skill": r.skill, "hours": r.hours, "level": r.level, "url": r.url, "free": r.free} for r in db.query(LearningResource).all()]
