from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..auth import current_user
from ..models import User, UserSkill
from ..schemas import SkillIn

router = APIRouter(prefix="/users", tags=["Profile"])

@router.get("/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "name": user.name, "email": user.email, "role": user.role, "location": user.location, "skills": [{"name": s.name, "level": s.level} for s in user.skills]}

@router.post("/me/skills")
def add_skill(data: SkillIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    existing = next((s for s in user.skills if s.name.lower() == data.name.lower()), None)
    if existing:
        existing.level = data.level
    else:
        db.add(UserSkill(user_id=user.id, name=data.name.strip(), level=data.level))
    db.commit()
    return {"ok": True}
