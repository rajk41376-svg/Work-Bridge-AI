from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..auth import current_user
from ..models import StartupResource, User

router = APIRouter(prefix="/startups", tags=["Entrepreneurship"])

@router.get("/resources")
def resources(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [{"id": r.id, "title": r.title, "category": r.category, "stage": r.stage, "description": r.description, "url": r.url} for r in db.query(StartupResource).all()]
