from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..auth import current_user
from ..models import User, Job, Application
from ..schemas import JobOut, MatchOut, ApplicationIn
from ..services.matching import score_job

router = APIRouter(prefix="/jobs", tags=["Jobs"])

def serialize(j):
    return {"id": j.id, "title": j.title, "company": j.company, "location": j.location, "remote": j.remote, "salary_min": j.salary_min, "salary_max": j.salary_max, "description": j.description, "skills": [x.strip() for x in j.skills.split(",") if x.strip()], "inclusive": j.inclusive}

@router.get("", response_model=list[JobOut])
def jobs(db: Session = Depends(get_db)):
    return [serialize(j) for j in db.query(Job).order_by(Job.created_at.desc()).all()]

@router.get("/matches", response_model=list[MatchOut])
def matches(user: User = Depends(current_user), db: Session = Depends(get_db)):
    result = []
    for j in db.query(Job).all():
        score, reasons = score_job(user, j)
        result.append({**serialize(j), "score": score, "reasons": reasons})
    return sorted(result, key=lambda x: x["score"], reverse=True)

@router.post("/apply")
def apply(data: ApplicationIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not db.get(Job, data.job_id):
        return {"ok": False, "message": "Job not found"}
    exists = db.query(Application).filter(Application.user_id == user.id, Application.job_id == data.job_id).first()
    if exists:
        return {"ok": True, "message": "Already applied"}
    db.add(Application(user_id=user.id, job_id=data.job_id)); db.commit()
    return {"ok": True, "message": "Application submitted"}
