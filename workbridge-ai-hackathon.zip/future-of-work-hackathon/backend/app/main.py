from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .db import Base, engine, SessionLocal
from .seed import seed
from .routers import auth, users, jobs, learning, startups, dashboard

app = FastAPI(title="WorkBridge AI API", version="1.0.0", description="Future of Work platform for inclusive employment and entrepreneurship.")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in settings.cors_origins.split(",")],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api")
app.include_router(users.router, prefix="/api")
app.include_router(jobs.router, prefix="/api")
app.include_router(learning.router, prefix="/api")
app.include_router(startups.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed(db)
    finally:
        db.close()

@app.get("/health")
def health():
    return {"status": "ok", "service": "workbridge-ai"}
