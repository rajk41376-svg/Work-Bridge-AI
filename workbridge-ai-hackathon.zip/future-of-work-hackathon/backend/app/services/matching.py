import re
from ..models import User, Job

def tokens(value: str):
    return {x.lower().strip() for x in re.split(r"[,;/|]+", value or "") if x.strip()}

def score_job(user: User, job: Job):
    user_skills = {s.name.lower(): s.level for s in user.skills}
    required = tokens(job.skills)
    matched = [s for s in required if s in user_skills]
    missing = [s for s in required if s not in user_skills]
    skill_score = (len(matched) / len(required) * 65) if required else 45
    level_bonus = min(15, sum(min(5, user_skills[s]) for s in matched) * 1.5)
    location_bonus = 10 if job.remote or job.location.lower() == user.location.lower() else 0
    inclusive_bonus = 10 if job.inclusive else 0
    total = round(min(99, skill_score + level_bonus + location_bonus + inclusive_bonus))
    reasons = []
    if matched:
        reasons.append(f"Strong skill overlap: {', '.join(sorted(matched)[:4])}")
    if missing:
        reasons.append(f"Upskill opportunity: {', '.join(sorted(missing)[:3])}")
    if job.remote:
        reasons.append("Remote-friendly role")
    if job.inclusive:
        reasons.append("Inclusive hiring signal")
    return total, reasons
