from ..models import User, Job
from .matching import tokens

def build_career_plan(user: User, jobs: list[Job]):
    if not jobs:
        return {"target_role": "Emerging Digital Professional", "readiness": 45, "gap_skills": [], "strengths": [], "next_actions": []}
    user_skills = {s.name.lower() for s in user.skills}
    candidates = []
    for job in jobs:
        required = tokens(job.skills)
        overlap = len(required & user_skills) / max(1, len(required))
        candidates.append((overlap, job))
    _, target = max(candidates, key=lambda x: x[0])
    required = tokens(target.skills)
    gaps = sorted(required - user_skills)
    strengths = sorted(required & user_skills)
    readiness = round((len(strengths) / max(1, len(required))) * 100)
    actions = [f"Build one portfolio project using {s}" for s in gaps[:2]]
    actions += ["Apply to 3 high-fit roles this week", "Complete a mock interview", "Update CV with measurable outcomes"]
    return {
        "target_role": target.title,
        "readiness": readiness,
        "gap_skills": gaps[:6],
        "strengths": strengths[:6],
        "next_actions": actions[:5],
    }
