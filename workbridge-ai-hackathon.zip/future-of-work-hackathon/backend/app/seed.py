from .models import Job, LearningResource, StartupResource

def seed(db):
    if db.query(Job).count() == 0:
        jobs = [
            Job(title="AI Product Associate", company="NovaWorks", location="Bengaluru", remote=True, salary_min=700000, salary_max=1200000, skills="python, product management, analytics, communication", description="Help ship AI products from research to launch.", inclusive=True),
            Job(title="Frontend Developer", company="OpenGrid", location="Hyderabad", remote=True, salary_min=600000, salary_max=1100000, skills="react, typescript, javascript, css", description="Build accessible digital products for millions of users.", inclusive=True),
            Job(title="Data Analyst", company="ImpactLabs", location="Pune", remote=False, salary_min=500000, salary_max=900000, skills="sql, python, excel, analytics", description="Turn operational data into decisions for social-impact programs.", inclusive=True),
            Job(title="MSME Automation Consultant", company="ScaleMitra", location="Mumbai", remote=True, salary_min=550000, salary_max=1000000, skills="automation, no-code, business analysis, communication", description="Digitize small businesses and automate repetitive workflows.", inclusive=True),
            Job(title="Community Growth Manager", company="SheBuilds", location="Delhi", remote=True, salary_min=450000, salary_max=800000, skills="marketing, communication, community, analytics", description="Grow an inclusive founder and creator community.", inclusive=True),
        ]
        db.add_all(jobs)
    if db.query(LearningResource).count() == 0:
        db.add_all([
            LearningResource(title="Python for Data & AI", provider="OpenLearn", skill="python", level="beginner", hours=12, url="https://www.python.org/", free=True),
            LearningResource(title="React + TypeScript Accelerator", provider="WorkBridge Academy", skill="react", level="intermediate", hours=16, url="https://react.dev/", free=True),
            LearningResource(title="SQL for Analytics", provider="WorkBridge Academy", skill="sql", level="beginner", hours=8, url="https://www.postgresql.org/docs/", free=True),
            LearningResource(title="Business Automation Fundamentals", provider="WorkBridge Academy", skill="automation", level="beginner", hours=10, url="#", free=True),
        ])
    if db.query(StartupResource).count() == 0:
        db.add_all([
            StartupResource(title="Founder Canvas", category="planning", stage="idea", description="Validate customer, problem, value proposition and business model.", url="#"),
            StartupResource(title="MSME Digital Starter Kit", category="digitization", stage="early", description="Templates for CRM, invoicing, inventory and customer support workflows.", url="#"),
            StartupResource(title="Pitch Deck Coach", category="fundraising", stage="growth", description="Build an investor-ready narrative and traction dashboard.", url="#"),
            StartupResource(title="Women Founder Network", category="community", stage="idea", description="Peer mentorship and access-to-market opportunities.", url="#"),
        ])
    db.commit()
