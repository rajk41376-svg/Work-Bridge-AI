# Smoke-test idea:
# 1) GET /health
# 2) POST /api/auth/register
# 3) GET /api/users/me with Bearer token
# 4) GET /api/jobs/matches with Bearer token
