import {ArrowUpRight, BriefcaseBusiness, CheckCircle2, GraduationCap, Target, TrendingUp} from "lucide-react"

export default function Dashboard({data,profile}:{data:any,profile:any}) {
 const cards=[
  ["Profile readiness",`${data.profile_completion}%`,profile?.skill_count ? `${profile.skill_count} skills mapped`:"Add skills to start",TrendingUp],
  ["AI match score",`${data.match_score}%`,"Across current roles",Target],
  ["Recommended roles",`${data.recommended_jobs}`,"70%+ fit",BriefcaseBusiness],
  ["Applications",`${data.applications}`,"Keep the momentum",GraduationCap],
 ]
 return <main>
  <section className="hero"><div><div className="eyebrow"><SparkleDot/> FUTURE-READY WORKFORCE</div><h1>Build a career that<br/><em>moves forward.</em></h1><p>AI-powered opportunities, skills and entrepreneurship support — designed for an inclusive future of work.</p></div><div className="hero-orb"><div className="orb-inner">AI<br/><span>CAREER<br/>COPILOT</span></div></div></section>
  <div className="grid4">{cards.map(([label,value,sub,Icon])=><div className="metric" key={label as string}><div className="metric-icon"><Icon size={18}/></div><span>{label}</span><strong>{value}</strong><small>{sub}</small></div>)}</div>
  <div className="two-col">
   <section className="panel"><div className="panel-head"><div><h2>SDG impact radar</h2><p>Your platform contribution score</p></div><ArrowUpRight size={19}/></div><div className="impact">{Object.entries(data.impact||{}).map(([k,v]:any)=><div className="impact-row" key={k}><span>SDG {k.replace("sdg","")}</span><div className="bar"><i style={{width:`${v}%`}}/></div>)}</div></section>
   <section className="panel"><div className="panel-head"><div><h2>Today’s focus</h2><p>Three actions to increase your career score</p></div></div><div className="checklist">{["Add one high-demand skill","Review your top 3 AI-matched jobs","Complete 30 minutes of targeted learning"].map(x=><div key={x}><CheckCircle2 size={18}/><span>{x}</span></div>)}</div></section>
  </div>
 </main>
}
function SparkleDot(){return <span className="sparkle-dot">✦</span>}
