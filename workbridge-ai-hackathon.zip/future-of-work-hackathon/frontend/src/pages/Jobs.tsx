import {useState} from "react"
import {CheckCircle2, MapPin, Sparkles, Wifi} from "lucide-react"
import {Job} from "../types"

export default function Jobs({jobs,onApply}:{jobs:Job[],onApply:(id:number)=>void}) {
 const [q,setQ]=useState("")
 const filtered=jobs.filter(j=>(j.title+" "+j.company+" "+j.skills.join(" ")).toLowerCase().includes(q.toLowerCase()))
 return <main><div className="page-title"><div><div className="eyebrow"><Sparkles size={14}/> AI MATCH ENGINE</div><h1>Roles built around <em>your potential.</em></h1><p>Explainable matching combines skills, location, work mode and inclusion signals.</p></div><input className="filter" value={q} onChange={e=>setQ(e.target.value)} placeholder="Filter roles..." /></div>
 <div className="job-list">{filtered.map(j=><article className="job-card" key={j.id}><div className="job-score">{j.score}%<span>FIT</span></div><div className="job-main"><div className="job-top"><div><h2>{j.title}</h2><b>{j.company}</b></div><button className="apply" onClick={()=>onApply(j.id)}>Apply now</button></div><div className="meta"><span><MapPin size={14}/>{j.location}</span>{j.remote&&<span><Wifi size={14}/>Remote</span>}{j.inclusive&&<span><CheckCircle2 size={14}/>Inclusive</span>}</div><p>{j.description}</p><div className="tags">{j.skills.map(s=><span key={s}>{s}</span>)}</div><div className="reasons">{(j.reasons||[]).map(r=><span key={r}>✦ {r}</span>)}</div></div></article>)}</div></main>
}
