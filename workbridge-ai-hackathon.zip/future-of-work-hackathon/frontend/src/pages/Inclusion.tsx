import {Accessibility, HeartHandshake, Languages, ShieldCheck} from "lucide-react"
export default function Inclusion() {
 const tools=[["Accessible job mode","Larger type, high contrast, keyboard-first navigation",Accessibility],["Bias-aware matching","Skills-first ranking with explainable match reasons",ShieldCheck],["Flexible work","Remote and flexible-work signals surfaced clearly",HeartHandshake],["Language access","Architecture ready for multilingual content and voice",Languages]]
 return <main><div className="page-title"><div><div className="eyebrow"><HeartHandshake size={14}/> INCLUSIVE EMPLOYMENT</div><h1>Opportunity should be <em>accessible.</em></h1><p>Product decisions that reduce barriers for women, youth, people with disabilities and underserved communities.</p></div></div>
 <div className="inclusion-grid">{tools.map(([title,desc,Icon])=><article className="panel inclusion-card" key={title as string}><div className="metric-icon"><Icon size={21}/></div><h2>{title}</h2><p>{desc}</p><button className="outline-btn">Configure</button></article>)}</div>
 <section className="panel ethics"><h2>Responsible AI guardrails</h2><div className="guardrails"><span>✓ Explainable recommendations</span><span>✓ User-controlled profile data</span><span>✓ No protected-attribute scoring</span><span>✓ Human review for employer decisions</span></div></section>
 </main>
}
