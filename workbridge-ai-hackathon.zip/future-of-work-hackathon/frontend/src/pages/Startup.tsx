import {ArrowUpRight, Building2, Lightbulb, Users} from "lucide-react"
export default function Startup({items}:{items:any[]}) {
 const icons:any={planning:Lightbulb,digitization:Building2,fundraising:ArrowUpRight,community:Users}
 return <main><div className="page-title"><div><div className="eyebrow"><Lightbulb size={14}/> ENTREPRENEURSHIP ENGINE</div><h1>Turn an idea into <em>momentum.</em></h1><p>Tools, templates and networks for founders and MSMEs at every stage.</p></div></div>
 <div className="startup-grid">{items.map(x=>{const Icon=icons[x.category]||Lightbulb;return <article className="startup-card" key={x.id}><div className="startup-icon"><Icon size={20}/></div><small>{x.category.toUpperCase()} · {x.stage}</small><h2>{x.title}</h2><p>{x.description}</p><button className="text-btn">Open resource <ArrowUpRight size={15}/></button></article>})}</div>
 <section className="founder-banner"><div><span>MSME DIGITAL SCORE</span><h2>Automate the busywork.<br/><em>Grow the business.</em></h2><p>Map invoicing, CRM, inventory and customer-support workflows into one practical digitization plan.</p></div><div className="score-ring">78<span>/100</span></div></section>
 </main>
}
