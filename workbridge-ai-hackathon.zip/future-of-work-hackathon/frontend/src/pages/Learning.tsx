import {BookOpen, Clock3, Target, Trophy} from "lucide-react"
export default function Learning({plan}:{plan:any}) {
 const c=plan?.career
 return <main><div className="page-title"><div><div className="eyebrow"><BookOpen size={14}/> PERSONALIZED UPSKILLING</div><h1>Your <em>skill runway.</em></h1><p>A learning path generated from your target role and current skill profile.</p></div></div>
 <div className="two-col"><section className="panel career-card"><div className="target"><Target/><div><small>TARGET ROLE</small><h2>{c?.target_role||"Discovering..."}</h2></div><strong>{c?.readiness||0}%</strong></div><div className="progress"><i style={{width:`${c?.readiness||0}%`}}/></div><div className="skill-columns"><div><h3>Strengths</h3>{(c?.strengths||[]).map((x:string)=><span className="skill-good" key={x}>✓ {x}</span>)}</div><div><h3>Priority gaps</h3>{(c?.gap_skills||[]).map((x:string)=><span className="skill-gap" key={x}>↗ {x}</span>)}</div></div></section>
 <section className="panel"><div className="panel-head"><div><h2>Recommended modules</h2><p>Short, practical and job-linked</p></div><Trophy size={20}/></div>{(plan?.resources||[]).map((r:any)=><div className="resource" key={r.title}><div className="resource-icon">↗</div><div><b>{r.title}</b><small>{r.provider} · {r.level}</small></div><span><Clock3 size={13}/> {r.hours}h</span></div>)}</section></div>
 <section className="panel actions"><h2>Next actions</h2>{(c?.next_actions||[]).map((x:string,i:number)=><div key={x}><b>0{i+1}</b><span>{x}</span></div>)}</section>
 </main>
}
