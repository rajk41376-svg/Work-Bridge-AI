import {Bell, Search, Sparkles} from "lucide-react"
export function Topbar({name}:{name:string}) {
 return <header className="topbar"><div className="search"><Search size={17}/><input placeholder="Search jobs, skills, founders..." /></div><div className="top-actions"><button className="icon-btn" aria-label="Notifications"><Bell size={18}/></button><div className="ai-pill"><Sparkles size={15}/> AI Copilot</div><div className="avatar">{name?.slice(0,1).toUpperCase() || "U"}</div></div></header>
}
