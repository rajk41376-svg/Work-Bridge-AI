import {BriefcaseBusiness, ChartNoAxesCombined, GraduationCap, Rocket, Settings2, Sparkles, UsersRound} from "lucide-react"

export function Sidebar({active,onChange}:{active:string,onChange:(x:string)=>void}) {
  const items = [
    ["dashboard","Overview",ChartNoAxesCombined],
    ["jobs","AI Job Match",Sparkles],
    ["learning","Skill Academy",GraduationCap],
    ["startup","Startup Hub",Rocket],
    ["inclusion","Inclusion",UsersRound],
  ] as const
  return <aside className="sidebar">
    <div className="brand"><div className="brandmark">W</div><div><b>WorkBridge</b><span>AI • FUTURE OF WORK</span></div></div>
    <nav>{items.map(([id,label,Icon])=><button key={id} className={active===id?"nav active":"nav"} onClick={()=>onChange(id)}><Icon size={18}/>{label}</button>)}</nav>
    <div className="sidebar-bottom"><button className="nav"><Settings2 size={18}/>Settings</button><div className="sdg-mini"><b>SDG Impact</b><span>8 · 1 · 4 · 5 · 9 · 10</span></div></div>
  </aside>
}
