export type Job = {
  id:number; title:string; company:string; location:string; remote:boolean;
  salary_min:number; salary_max:number; description:string; skills:string[];
  inclusive:boolean; score?:number; reasons?:string[];
}
export type Profile = {
  id:number; name:string; email:string; role:string; location:string;
  skills:{name:string; level:number}[]
}
