import {useEffect,useState} from "react"
import {LogOut, Menu, Sparkles} from "lucide-react"
import {api} from "./lib/api"
import {Sidebar} from "./components/Sidebar"
import {Topbar} from "./components/Topbar"
import Dashboard from "./pages/Dashboard"
import Jobs from "./pages/Jobs"
import Learning from "./pages/Learning"
import Startup from "./pages/Startup"
import Inclusion from "./pages/Inclusion"

export default function App(){
 const [authed,setAuthed]=useState(!!localStorage.getItem("workbridge_token"))
 const [login,setLogin]=useState(true)
 const [profile,setProfile]=useState<any>(null), [data,setData]=useState<any>(null)
 const [page,setPage]=useState("dashboard"), [jobs,setJobs]=useState<any[]>([]), [plan,setPlan]=useState<any>(null), [startup,setStartup]=useState<any[]>([])
 const [email,setEmail]=useState(""),[password,setPassword]=useState(""),[name,setName]=useState(""),[error,setError]=useState("")

 async function load(){
  try{
   const [p,d,m,l,s]=await Promise.all([api.me(),api.dashboard(),api.matches(),api.plan(),api.startup()])
   setProfile(p);setData(d);setJobs(m);setPlan(l);setStartup(s)
  }catch(e:any){setError(e.message);logout()}
 }
 useEffect(()=>{if(authed)load()},[authed])
 async function submit(e:any){e.preventDefault();setError("");try{const x=login?await api.login({email,password}):await api.register({name,email,password,role:"candidate",location:"Bengaluru"});localStorage.setItem("workbridge_token",x.access_token);setAuthed(true)}catch(e:any){setError(e.message)}}
 function logout(){localStorage.removeItem("workbridge_token");setAuthed(false)}
 if(!authed) return <div className="auth-shell"><div className="auth-art"><div className="brand"><div className="brandmark">W</div><div><b>WorkBridge</b><span>AI • FUTURE OF WORK</span></div></div><div><div className="eyebrow"><Sparkles size={14}/> HACKATHON PLATFORM</div><h1>Opportunity,<br/><em>intelligently connected.</em></h1><p>Jobs. Skills. Entrepreneurship. One inclusive career operating system.</p><div className="auth-pills"><span>SDG 8</span><span>SDG 4</span><span>SDG 5</span><span>SDG 9</span><span>SDG 10</span></div></div></div>
 <form className="auth-card" onSubmit={submit}><h2>{login?"Welcome back":"Create your profile"}</h2><p>{login?"Continue your future-of-work journey.":"Start with a skills-first career profile."}</p>{!login&&<input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name" required/>}<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email address" required/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" required/>{error&&<div className="error">{error}</div>}<button className="primary">{login?"Sign in":"Create account"}</button><button type="button" className="switch" onClick={()=>setLogin(!login)}>{login?"Need an account? Create one":"Already registered? Sign in"}</button></form></div>
 return <div className="app"><Sidebar active={page} onChange={setPage}/><div className="content"><Topbar name={profile?.name||"User"}/><div className="mobile-menu"><button onClick={()=>setPage("jobs")}><Menu size={18}/> Explore jobs</button><button onClick={logout}><LogOut size={18}/></button></div>{page==="dashboard"&&<Dashboard data={data||{}} profile={profile}/>} {page==="jobs"&&<Jobs jobs={jobs} onApply={async id=>{await api.apply(id);alert("Application submitted!")}}/>}{page==="learning"&&<Learning plan={plan}/>} {page==="startup"&&<Startup items={startup}/>} {page==="inclusion"&&<Inclusion/>}</div></div>
}
