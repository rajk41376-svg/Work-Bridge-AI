const API = import.meta.env.VITE_API_URL || "http://localhost:8000/api"

async function request<T>(path:string, options:RequestInit = {}):Promise<T> {
  const token = localStorage.getItem("workbridge_token")
  const headers = new Headers(options.headers)
  headers.set("Content-Type", "application/json")
  if (token) headers.set("Authorization", `Bearer ${token}`)
  const res = await fetch(`${API}${path}`, {...options, headers})
  if (!res.ok) {
    const body = await res.json().catch(() => ({}))
    throw new Error(body.detail || "Request failed")
  }
  return res.json()
}
export const api = {
  login:(data:any)=>request<{access_token:string}>("/auth/login",{method:"POST",body:JSON.stringify(data)}),
  register:(data:any)=>request<{access_token:string}>("/auth/register",{method:"POST",body:JSON.stringify(data)}),
  me:()=>request<any>("/users/me"),
  addSkill:(data:any)=>request<any>("/users/me/skills",{method:"POST",body:JSON.stringify(data)}),
  dashboard:()=>request<any>("/dashboard"),
  matches:()=>request<any[]>("/jobs/matches"),
  jobs:()=>request<any[]>("/jobs"),
  apply:(job_id:number)=>request<any>("/jobs/apply",{method:"POST",body:JSON.stringify({job_id})}),
  plan:()=>request<any>("/learning/plan"),
  startup:()=>request<any[]>("/startups/resources")
}
