# WorkBridge AI — Future of Work Hackathon Platform

An advanced full-stack prototype aligned with **SDG 8, 1, 4, 5, 9 and 10**.

### Core modules
- AI-powered job and skill matching
- Career recommendations and workforce planning
- Personalized upskilling / learning plans
- MSME digitization and business automation
- Entrepreneurship and startup support
- Inclusive employment and productivity tools
- JWT authentication
- PostgreSQL persistence
- Dockerized development
- Accessible, responsive React dashboard
- Deterministic AI scoring engine that can be replaced with an LLM/vector model

## Architecture

```text
React + TypeScript + Vite
        |
        | REST / JWT
        v
FastAPI + SQLAlchemy
        |
        +---- Matching Engine
        +---- Career / Learning Engine
        +---- Startup Recommendation Engine
        |
        v
PostgreSQL
```

## Run locally

### 1. Backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

API: `http://localhost:8000`
Swagger: `http://localhost:8000/docs`

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend: `http://localhost:5173`

### 3. Docker

From the project root:

```bash
docker compose up --build
```

## Demo account

Register from the UI. For a quick demo, the API also exposes:

```text
POST /api/auth/register
```

Example payload:

```json
{
  "name": "Aarav Kumar",
  "email": "aarav@example.com",
  "password": "password123",
  "role": "candidate",
  "location": "Bengaluru"
}
```

## Production upgrades

1. Replace deterministic matching with embeddings + a vector database.
2. Add OAuth/Google/LinkedIn login.
3. Add background jobs using Celery/Redis.
4. Add real LMS, government-skills and job-board integrations.
5. Add audit logs, consent management and model explainability reports.
6. Add employer verification and fraud detection.
7. Add multilingual speech/chat assistance.
